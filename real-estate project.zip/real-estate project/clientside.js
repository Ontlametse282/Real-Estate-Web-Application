<script>

//function to validate user input

function validate() {

var Location= document.getElementById("txtLocation").value;//location input validation

var Buy= document.getElementById("txtBuy").value;//purchase input validation

var Sell= document.getElementById("txtSell").value;//sell input validation

var Rent= document.getElementById("txtRnet").value;//rent input validation

//Email expression

var emailExp = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

//checking first name

if (First Name == "") {

//if first name is empty

alert("Enter First Name");//display alert

return false;//not allowed to submit form

}

else if (Last Name == "") {

//if last name is empty

alert("Enter last Name");//display alert

return false;//not allowed to submit form

}

else if (Email Address == "") {

//if email is empty

alert("Enter email");//display alert

return false;//not allowed to submit form

}//checking value for email

else if (!emailExp.test(Email Address)) {

alert("Invalid email");//display if email is invalid

return false;//not allowed to submit form

}

else {

//if all validation pass then

alert("Validation pass");

return true;

}



}
