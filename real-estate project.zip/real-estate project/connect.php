<?php

// Prompting the user to enter location
$Location = filter_input(INPUT_POST, 'Location');
// Prompting the user to enter desired house to buy
$Buy = filter_input(INPUT_POST, 'Buy');
//Prompting the user to desired house to sell
$Sell = filter_input(INPUT_POST, 'Sell');
//Prompting the user to desired house to sell
$Rent = filter_input(INPUT_POST, 'Rent');

if (!empty($Location)){
if (!empty($Buy)){
if (!empty($Sell)){
if (!empty($Rent)){	
$host = "localhost";
$dbLocation = "Zimbali","Pretoria","Cape Town", "Durban", "Fourways";
$dbBuy = "Apartment", "House";
$dbSell = "Apartment", "House";
$dbRent = "Apartment", "House";
// Creating a connection
$conn = new mysqli ($host, $dbLocation, $dbBuy $dbSell, $dbRent);

if (mysqli_connect_error()){
	die('Connect Error('. mysqli_connect_errno() .') '
		. mysqli_connect_error());
}
else{
	// inserting data into the sql server
	$sql = "INSERT INTO account  (Location, Buy, Sell, Rent)
	values = ('$Location', '$Buy', '$Sell,'$Rent')";
	if ($conn->query($sql)){
		echo "New record added successfully"
	}
	else{
		echo "Error: ". $sql ."<cbr>". $conn->error;
	}
	// Closing connection on the sql server 
	$conn->close();
else{
	echo "Invalid input"
	die();
}
} 
else{
	echo "Invalid input"
	die();
}
?>



	

