--Create a table named real_estate
CREATE TABLE real_estate (
    Id INT (200),
    Fname CHAR (255),
    Lname CHAR (255),
    Salary FLOAT (180)